<?php
require_once '../inc/init.inc.php';
require_once '../inc/admin/adminHeader.inc.php';


?>
<div class="row">
    <div class="col-8 alert alert-primary text-center offset-2">
        <h1 class="text-primary">espace admin</h1>
    </div>
</div>