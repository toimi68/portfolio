<?php
//Variable d'affichage :
//$isAdmin="";
//Connexion à la BDD et récupération des infos admin :
$req = $pdo->query("SELECT * FROM  user");
$admin = $req->fetch(PDO::FETCH_ASSOC);

//Contrôle des champs pour la connexion :
if($_POST){
if(!isset($_POST['uemail']) || !filter_var($_POST['uemail'],FILTER_VALIDATE_EMAIL ) || $_POST['uemail'] != $admin['uemail'] && !isset
($_POST['upassword']) || $_POST['upassword'] != $admin['upassword'] && $admin['ustatut'] != 1){

//$isAdmin .='<div class="alert alert-warning">Vous n\'avez pas rentrez les bonnes infos</div>';
header('location:../index.php');

}
header('location:../admin/gestionIndex.php');

}
/*>>>>> DECONEXION >>>>>*/
if(isset($_GET['action']) && $_GET['action'] === 'deconnexion'){
unset($_SESSION['admin']);
header('location : ../index.php');
}